class MiClase:
    '''
    Este es un ejemplo de la documentación
    de nuestra clase
    '''

    def __init__(self):
        '''
        Método de inicio
        de nuestra clase
        '''

    def mi_metodo(self, param1, param2):
        '''
        Esta es la documentación de nuestro método
        :param param1 Este es parámetro1:
        :param param2 Este es parámetro2:
        :return Este es el valor de retorno:
        '''